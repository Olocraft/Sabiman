import { useEffect, useRef, useState } from "react";
import { GpsFixed } from "@mui/icons-material";
import toast from "react-hot-toast";
import { GOOGLE_MAP, MAP_API, loadAsyncScript } from "../config/config";
import { useSelector, useDispatch } from "react-redux";
import ModalMap from "../Components/Modals/ModalMap";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import Footer from "../Components/layout/Footer";
import {
  locationAddressData,
  setIsBrowserSupported,
  setLatitude,
  setLongitude,
} from "../redux/Location";
import { getFormattedAddress } from "../util/Helper";
import { store } from "../redux/store";
import OurServices from "../Components/LandingPageSections/OurServices";
import Testimonials from "../Components/LandingPageSections/Testimonials";
import Faqs from "../Components/LandingPageSections/Faqs";
import { setModal } from "../redux/Settings";
import api from "../API/apiCollection";
import Process from "../Components/LandingPageSections/Process";
import { t } from "i18next";

const StartPage = () => {
  const inputRef = useRef(null);
  const dispatch = useDispatch();
  const settings = useSelector((state) => state.Settings?.settings);

  const [landingPage, setLandingPage] = useState([]);

  const [loading, setLoading] = useState(false);

  const { modal } = useSelector((state) => state.Settings);
  const web_settings = settings?.web_settings;

  const isBrowserSupported = store.getState()?.Location?.IsBrowserSupported;

  useEffect(() => {
    if ("Notification" in window) {
      if (Notification.permission !== "granted") {
        Notification.requestPermission();
      }
    } else {
      console.log("This browser does not support desktop notifications.");
    }

    const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    if (isSafari) {
      dispatch(setIsBrowserSupported(false));
      return;
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        () => {
          dispatch(setIsBrowserSupported(true));
        },
        (error) => {
          console.error("Geolocation error:", error);
          dispatch(setIsBrowserSupported(true));
        }
      );
    } else {
      console.log("Geolocation not supported");
      dispatch(setIsBrowserSupported(true));
    }
  }, [dispatch]);

  const initMapScript = () => {
    if (window.google) {
      return Promise.resolve();
    }
    const src = `${GOOGLE_MAP}?key=${MAP_API}&libraries=places&v=weekly`;
    return loadAsyncScript(src);
  };

  const initAutocomplete = () => {
    const isGoogleMapsAvailable =
      inputRef.current && window.google && window.google.maps;

    if (isGoogleMapsAvailable) {
      const autocomplete = new window.google.maps.places.Autocomplete(
        inputRef.current,
        {
          fields: ["address_component", "geometry"],
        }
      );

      autocomplete.addListener("place_changed", () => {});
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      handleSearch();
    }
  };

  const handleSearch = () => {
    const value = inputRef.current?.value;
    if (value) {
      const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
        value
      )}&key=${MAP_API}`;

      fetch(geocodeUrl)
        .then((response) => response.json())
        .then((data) => {
          const { results } = data;
          if (results?.length > 0) {
            const { lat, lng } = results[0].geometry.location;
            dispatch(setLatitude(lat));
            dispatch(setLongitude(lng));
            dispatch(setModal(true));
          } else {
            console.log("No results found");
          }
        })
        .catch((error) => {
          console.error(error);
        });
    }
  };

  useEffect(() => {
    initMapScript().then(() => initAutocomplete());
  }, []);

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          dispatch(setLatitude(position.coords.latitude));
          dispatch(setLongitude(position.coords.longitude));
          dispatch(setModal(true));
          await getFormattedAddress(
            position.coords.latitude,
            position.coords.longitude
          ).then((res) => {
            dispatch(locationAddressData(res));
          });
        },
        (error) => {
          if (error.code === error.PERMISSION_DENIED) {
            toast.error(t("enable_location"));
          } else {
            console.error(error.message);
            toast.error("Error getting location: " + error.message);
          }
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
        }
      );
    } else {
      toast.error(t("geolocation_not_supported"));
    }
  };

  useEffect(() => {
    const getLandingPageData = async () => {
      setLoading(true);
      try {
        const response = await api.getWebLandingPageApi();
        setLandingPage(response.data); // Ensure this matches 'any[]'
        setLoading(false);
      } catch (error) {
        setLoading(false);
        console.error(error);
      }
    };
    getLandingPageData();
  }, []);

  return (
    <>
      <div className="startpage">
        <div className="header-main">
          <div className="container custom-Container">
            <div className="row">
              <div className="edemand-logo">
                <img src={web_settings?.landing_page_logo} alt="logo" />
              </div>
            </div>
          </div>
        </div>
        <div className="edemand-content">
          <div className="container custom-Container">
            <div className="row">
              <div className="edemand-center-data">
                <div className="edemand-title">
                  <h1>{web_settings?.landing_page_title}</h1>
                </div>
                <div className="edemand-input">
                  <LocationOnIcon />
                  <input
                    type="text"
                    placeholder="Enter Location, Area or City Name etc..."
                    ref={inputRef}
                    onKeyPress={handleKeyPress}
                  />
                  <div className="edemand-current-location-get">
                    {isBrowserSupported && (
                      <button
                        className="btn"
                        onClick={() => getCurrentLocation()}
                      >
                        {" "}
                        <GpsFixed className="location-icon" />
                        <span>locate me</span>
                      </button>
                    )}
                  </div>
                  <div className="edemand-search">
                    <button className="btn btn-theme" onClick={handleSearch}>
                      Search
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="background_image_main">
          <div
            className="edemand-backgroung-image"
            style={{
              backgroundImage: `url(${web_settings?.landing_page_backgroud_image})`,
            }}
          ></div>
        </div>

        {/* services */}
        {landingPage?.category_section_status === 1 ? (
          <OurServices landingPage={landingPage} loading={loading} />
        ) : null}

        {/* ratings */}
        {landingPage?.rating_section_status === 1 ? (
          <Testimonials landingPage={landingPage} loading={loading} />
        ) : null}

        {/* how it works */}
        {landingPage?.process_flow_status === 1 ? (
          <Process landingPage={landingPage} loading={loading} />
        ) : null}

        {/* faqs */}
        {landingPage?.faq_section_status === 1 ? (
          <Faqs landingPage={landingPage} loading={loading} />
        ) : null}

        {/* footer */}
        <Footer />
      </div>

      <div className="container ">
        {modal === true ? <ModalMap redirect={true}></ModalMap> : ""}
      </div>
    </>
  );
};

export default StartPage;
