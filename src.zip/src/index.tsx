import { Suspense } from "react";
import ReactDOM from "react-dom/client";
import { store, persistor } from "./redux/store";
import { Provider } from "react-redux";
import App from "./App";
import PushNotificationLayout from "./Components/FirebaseNotification/PushNotificationLayout";
import { PersistGate } from "redux-persist/integration/react";
import "./i18n";
import { BrowserRouter } from "react-router-dom";
import Loader from "./Components/Loader";
import { Toaster } from "react-hot-toast";
import "./CSS/bootstrap.min.css";
import "./CSS/style.css";
import "./CSS/darkmode.css";


const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);

root.render(
  <>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <PushNotificationLayout>
          <Suspense fallback={<Loader />}>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </Suspense>
        </PushNotificationLayout>
      </PersistGate>
    </Provider>
    <Toaster />
  </>
);
