import React from "react";

const Seo = ({ title }) => {

    return (
        <>
            <meta charSet="utf-8" />
            {/* <link rel="icon" href={faviconimage} />
            <title>{appName + " | " + title}</title>
            <meta name="robots" content="INDEX,FOLLOW" />
            <meta name="description" content={description} />
            <meta name="keywords" content={metakeywords}></meta>
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
            <meta property="og:title" content={appName + " | " + title} />
            <meta property="og:description" content={description} />
            <meta property="og:type" content="website" /> */}
        </>
    );
};


export default Seo;