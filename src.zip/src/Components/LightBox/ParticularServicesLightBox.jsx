import React, { useState } from "react";
import Modal from "react-modal";
import CustomVideoModal from "./CustomVideoModal";
import { UrlType, getUrlType, placeholderImage } from "../../util/Helper";
import CustomLightBox from "./CustomLightBox";

Modal.setAppElement("#root"); // Important for accessibility

const ParticularServicesLightBox = ({ urls, setLightBoxState }) => {
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [videoUrl, setVideoUrl] = useState("");

  const handleClick = (url, type, index) => {
    try {
      if (type === UrlType.IMAGE) {
        setLightboxIndex(index);
        setIsLightboxOpen(true);
        setLightBoxState(true);
      } else if (type === UrlType.VIDEO) {
        setVideoUrl(url);
        setIsVideoModalOpen(true);
        setLightBoxState(true);
      }
    } catch (error) {
      setLightBoxState(false);
      console.error("Error handling click:", error);
    }
  };

  const renderUrls = () => {
    try {
      return urls.map((url, index) => {
        const type = getUrlType(url);
        return (
          <div
            key={index}
            onClick={() => handleClick(url, type, index)}
            className="parent_div"
          >
            {type === UrlType.IMAGE ? (
              <img src={url} alt="work evidence" onError={placeholderImage} />
            ) : (
              <video className="video_data" src={url} />
            )}
          </div>
        );
      });
    } catch (error) {
      console.error("Error rendering URLs:", error);
      return null;
    }
  };

  const images = urls
    ?.filter((url) => getUrlType(url) === UrlType.IMAGE)
    ?.map((url) => ({ src: url }));

  const gotoPrevious = () => {
    // Calculate the previous index
    const newIndex = (lightboxIndex + images?.length - 1) % images?.length;
    setLightboxIndex(newIndex);
  };

  const gotoNext = () =>
    setLightboxIndex((prevIndex) => (prevIndex + 1) % images?.length);

  const lightBoxClose = () => {
    setLightBoxState(false);
    setIsLightboxOpen(false);
  };

  return (
    <div className="main-lightbox">
      <div className="all-images">{renderUrls()}</div>

      {isLightboxOpen && (
        <>
          <CustomLightBox
            lightboxOpen={isLightboxOpen}
            currentImages={images}
            currentImageIndex={lightboxIndex}
            handleCloseLightbox={lightBoxClose}
            gotoNext={gotoNext}
            gotoPrevious={gotoPrevious}
          />
        </>
      )}
      {isVideoModalOpen && (
        <CustomVideoModal
          isOpen={isVideoModalOpen}
          videoUrl={videoUrl}
          onClose={() => setIsVideoModalOpen(false)}
        />
      )}
    </div>
  );
};

export default ParticularServicesLightBox;
