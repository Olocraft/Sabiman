import { useEffect } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import api from "../../API/apiCollection";
import { useDispatch, useSelector } from "react-redux";
import {
  locationAddressData,
  setLatitude,
  setLongitude,
  setModalClose,
} from "../../redux/Location";
import { setProviderAvailable } from "../../redux/Provider";
import { getFormattedAddress } from "../../util/Helper";
import toast from "react-hot-toast";
import { Divider, IconButton } from "@mui/material";
import { Close } from "@mui/icons-material";
import { useNavigate } from "react-router";
import { useTheme } from "@emotion/react";
import { t } from "i18next";
import { setModal } from "../../redux/Settings";
import GoogleMapBox from "../GoogleMap/GoogleMapBox";
import { MAP_API } from "../../config/config";

const ModalMap = ({ redirect }) => {

  const navigate = useNavigate();
  
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: { xs: "90%", md: "60%" },
    bgcolor: "background.paper",
    boxShadow: 24,
    borderRadius: "var(--global-border-radius)",
    p: 2,
  };

  const { modal } = useSelector((state) => state.Settings);

  const locationData = useSelector((state) => state.Location);

  const dispatch = useDispatch();

  useEffect(() => {}, [locationData]);

  const handleClose = () => {
    dispatch(setModal(false));
    dispatch(setModalClose(false));
  };

  const setLocation = async () => {
    try {
      const data = await api.providerAvailable({
        latitude: locationData.lat,
        longitude: locationData.lng,
        isCheckout: 0,
      });
      if (data?.error === false) {
        dispatch(setProviderAvailable(true));
        dispatch(setLatitude(locationData.lat));
        dispatch(setLongitude(locationData.lng));
        dispatch(setModalClose(false));
        const address = await getFormattedAddress(locationData.lat, locationData.lng);
        dispatch(locationAddressData(address));
        navigate("/");
      } else {
        toast.error(t("our_service_not_area"));
        if (redirect) {
          dispatch(setProviderAvailable(false));
          dispatch(setModal(false));
          dispatch(setModalClose(false));
        }
      }
    } catch (error) {
      console.error(error);
    }
  };


  const theme = useTheme();

  const handleLocationSelect = (data) => {
    dispatch(setLatitude(data?.lat));
    dispatch(setLongitude(data?.lng));
    dispatch(locationAddressData(data?.formatted_address));
  };


  return (
    <Box>
      <Modal
        open={modal}
        onClose={() => handleClose()}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Box
            mt={1}
            display={"flex"}
            justifyContent={"space-between"}
            alignItems={"center"}
          >
            <Typography variant="h6" color={theme.palette.text.primary}>
              {t("select_map_location")}
            </Typography>
            <IconButton onClick={() => handleClose()}>
              <Close />
            </IconButton>
          </Box>
          <Divider sx={{ width: "100%", mb: 3 }} />

          <GoogleMapBox
            onSelectLocation={handleLocationSelect}
            apiKey={MAP_API}
            isLocationPass={true}
            locationlat={locationData.lat}
            locationlng={locationData.lng}
          />

          <Button
            fullWidth
            sx={{ mt: 2 }}
            variant="contained"
            color="primary"
            onClick={(e) => setLocation()}
          >
            Use this location
          </Button>
        </Box>
      </Modal>
    </Box>
  );
};

export default ModalMap;
