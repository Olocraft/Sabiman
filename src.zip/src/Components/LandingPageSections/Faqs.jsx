import { useEffect, useState } from "react";
import Accordion from "react-bootstrap/Accordion";
import CommonTextSkeleton from "../Reusable/Sections/LandingPageSkeletons/CommonTextSkeleton";
import FaqsSkeleton from "../Reusable/Sections/LandingPageSkeletons/FaqsSkeleton";
import api from "../../API/apiCollection";

const Faqs = ({ landingPage }) => {

  const [activeKey, setActiveKey] = useState(null);

  const handleToggle = (id) => {
    setActiveKey(activeKey === id ? null : id);
  };

  const [loading, setLoading] = useState(false);

  const [faqData, setFaqData] = useState([]);

  const allData = async () => {
    setLoading(true);

    try {
      const faqResponse = await api.get_Faqs({});
      const { data: faqdata } = faqResponse.data;
      setFaqData(faqdata);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    allData();
  }, []);

  return (
    <>
      {faqData?.length > 0 && (
        <section className="faqsSect">
          <div className="container cutom-container">
            {loading ? (
              <CommonTextSkeleton />
            ) : (
              <div className="textWrapper">
                <span className="heading">
                  {landingPage?.faq_section_title}
                </span>
                <span className="para">
                  {landingPage?.faq_section_description}
                </span>
              </div>
            )}

            <div className="faqsDiv">
              {loading ? (
                <FaqsSkeleton />
              ) : (
                <Accordion defaultActiveKey="0">
                  <div className="row">
                    {faqData.map((data) => (
                      <div className="col-md-6 mb-4" key={data.id}>
                        <Accordion.Item eventKey={data.id} >
                          <Accordion.Header onClick={() => handleToggle(data.id)}>
                            {data.question}
                          </Accordion.Header>
                          <Accordion.Body>
                            {data.answer}
                          </Accordion.Body>
                        </Accordion.Item>
                      </div>
                    ))}
                  </div>
                </Accordion>
              )}
            </div>
          </div>
        </section>
      )}
    </>
  );
};

export default Faqs;
