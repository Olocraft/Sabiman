import { useCallback, useRef } from "react";
import quotesIcon from "../../Images/quotes.png";
import { FaAngleRight, FaAngleLeft } from "react-icons/fa6";
import { Swiper, SwiperSlide } from "swiper/react";
import { FaStar } from "react-icons/fa";
import TestimonioalSkeleton from "../Reusable/Sections/LandingPageSkeletons/TestimonioalSkeleton";
import { placeholderImage, truncate } from "../../util/Helper";

const Testimonials = ({ landingPage, loading }) => {
  const breakpoints = {
    0: {
      slidesPerView: 1,
    },
    375: {
      slidesPerView: 1,
    },
    576: {
      slidesPerView: 1.5,
    },
    768: {
      slidesPerView: 2,
    },
    992: {
      slidesPerView: 2.5,
    },
    1200: {
      slidesPerView: 2,
    },
    1400: {
      slidesPerView: 3,
    },
  };

  const sliderRef = useRef(null);

  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return;

    sliderRef.current.swiper.slidePrev();
  }, []);

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slideNext();
  }, []);

  return loading ? (
    <TestimonioalSkeleton />
  ) : (
    landingPage?.ratings?.length > 0 && (
      <section className="testimonials">
        <div className="container custom-Container">
          <div className="row">
            <div className="col-lg-3 textDiv">
              <div className="textWrapper">
                <span className="heading">{landingPage?.rating_section_title}</span>
                <span className="para">{landingPage?.rating_section_description}</span>

                {landingPage?.ratings?.length > 3 && (
                  <div className="navigationBtns">
                    <div className="swiper-button-prev" onClick={handlePrev}>
                      <FaAngleLeft size={20} />
                    </div>
                    <div className="swiper-button-next" onClick={handleNext}>
                      <FaAngleRight size={20} />
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="col-lg-9">
              <div className="testimonialSwiper">
                <Swiper
                  ref={sliderRef}
                  slidesPerView={3}
                  loop={landingPage?.ratings?.length > 3 ? true : false}
                  spaceBetween={30}
                  className="testiSwiper"
                  breakpoints={breakpoints}
                >
                  {landingPage?.ratings.map((ele, index) => {
                    return (
                      <SwiperSlide key={ele.id}>
                        <div className="card testimonialsCard">
                          <div className="quotesImg">
                            <img
                              src={quotesIcon}
                              alt="quotesIcon"
                              onError={placeholderImage}
                            />
                          </div>
                          <div>
                            <span className="comment">
                              {truncate(ele.comment, 80)}
                            </span>
                          </div>

                          <div className="profileWrapper">
                            <div className="profile">
                              <div>
                                <img
                                  src={ele.profile_image}
                                  alt="profile"
                                  onError={placeholderImage}
                                />
                              </div>
                              <div className="text">
                                <span>{truncate(ele.user_name, 15)}</span>
                                <span>{truncate(ele.service_name, 15)}</span>
                              </div>
                            </div>

                            <div className="ratingDiv">
                              <span>{ele.rating}</span>
                              <span>
                                <FaStar />
                              </span>
                            </div>
                          </div>
                        </div>
                      </SwiperSlide>
                    );
                  })}
                </Swiper>
              </div>
            </div>
          </div>
        </div>
      </section>
    )
  );
};

export default Testimonials;
