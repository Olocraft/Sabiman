import { placeholderImage } from "../../util/Helper";

const Process = ({ landingPage }) => {
  return (
    <>
      <div className="how-it-works">
        <div className="container custom-Container">
          <div className="how-title">
            <h2>{landingPage?.process_flow_title}</h2>
            <p>{landingPage?.process_flow_description}</p>
          </div>

          <div className="row">
            {landingPage?.process_flow_data &&
              landingPage?.process_flow_data.map((data) => (
                <div className="col-md-3 col-12" key={data.id}>
                  <div className="card">
                    <div className="how-it-works-card-body">
                      <div className="card-image">
                        <img
                          src={data?.image}
                          alt="works"
                          onError={placeholderImage}
                        />
                        <div className="card-numbers">
                          <p>{data?.id}</p>
                        </div>
                      </div>

                      <h5 className="how-it-works-card-title">
                        <i className="fas fa-map-marker-alt"></i>
                      </h5>
                      <p className="how-it-works-card-text">{data?.title}</p>
                      <p className="how-it-works-card-content">
                        {data?.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Process;
