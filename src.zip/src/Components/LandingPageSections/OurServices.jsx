import { useCallback, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import OurServicesSkeleton from "../Reusable/Sections/LandingPageSkeletons/OurServicesSkeleton";
import { FaAngleRight, FaAngleLeft } from "react-icons/fa6";
import { placeholderImage } from "../../util/Helper";

const OurServices = ({ landingPage, loading }) => {
  const breakpoints = {
    0: {
      slidesPerView: 1,
      // spaceBetween: 40
    },
    375: {
      slidesPerView: 1,
      // spaceBetween: 40
    },
    576: {
      slidesPerView: 2,
      // spaceBetween: 40
    },
    768: {
      slidesPerView: 3,
    },
    992: {
      slidesPerView: 4,
    },
    1200: {
      slidesPerView: 4,
    },
    1400: {
      slidesPerView: 6,
    },
  };

  const sliderRef = useRef(null);

  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return;

    sliderRef.current.swiper.slidePrev();
  }, []);

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slideNext();
  }, []);

  return loading ? (
    <OurServicesSkeleton />
  ) : (
    landingPage?.categories?.length > 0 && (
      <section className="ourServices">
        <div className="container custom-Container">
          <div className="textWrapper">
            {/* <span className='heading'>Our <span>Services</span></span> */}
            <span className="heading">{landingPage?.category_section_title}</span>
            <span className="para">{landingPage?.category_section_description}</span>
          </div>

          <div className="servicesCards">
            <Swiper
              ref={sliderRef}
              slidesPerView={3}
              loop={landingPage.categories?.length > 6 ? true : false}
              spaceBetween={30}
              modules={[Navigation, Pagination]}
              className="testiSwiper"
              breakpoints={breakpoints}
            >
              {landingPage?.categories?.map((ele, index) => {
                return (
                  <SwiperSlide key={ele.id}>
                    <div className="card">
                      <div className="imgDiv">
                        <img
                          src={ele.image}
                          alt="servicesImg"
                          onError={placeholderImage}
                        />
                      </div>
                      <div>
                        <span className="serviceName">{ele.name}</span>
                      </div>
                    </div>
                  </SwiperSlide>
                );
              })}
            </Swiper>

            {landingPage?.categories?.length > 6 && (
              <div className="navigationBtns">
                <div className="swiper-button-prev" onClick={handlePrev}>
                  <FaAngleLeft size={20} />
                </div>
                <div className="swiper-button-next" onClick={handleNext}>
                  <FaAngleRight size={20} />
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    )
  );
};

export default OurServices;
