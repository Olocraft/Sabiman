/* eslint eqeqeq: 0 */
import { useEffect, useState } from "react";
import {
  AccessTime,
  CloseOutlined,
  EventNoteOutlined,
  LocationOnOutlined,
} from "@mui/icons-material";
import {
  Box,
  Button,
  Container,
  Dialog,
  DialogTitle,
  Divider,
  Grid,
  Typography,
  useTheme,
  IconButton,
  FormLabel,
  Radio,
  Card,
  CardMedia,
  Drawer,
} from "@mui/material";
import { t } from "i18next";
import Heading from "../Heading";
import { useNavigate, useParams } from "react-router";
import Layout from "../../../layout/Layout";
import Pnavigation from "../Pnavigation";
import api from "../../../../API/apiCollection";
import toast from "react-hot-toast";
import Calendar from "react-calendar";
import dayjs from "dayjs";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";
import RatingModal from "../../../Modals/RatingModal";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { setReorder, setFrom } from "../../../../../src/redux/cart";
import { getStatusClassName, placeholderImage } from "../../../../util/Helper";
import { setPromoCode } from "../../../../../src/redux/Promocode";
import "react-calendar/dist/Calendar.css";
import UrlTypeComponent from "../../../LightBox/UrlTypeComponent";
import ConfirmDateTime from "../../../../Drawers/ConfirmDataTime";
import Promocode from "../../../../Drawers/Promocode";
import { handleClose, handleOpen } from "../../../../config/config";
import AddAddressForm from "../../../../Drawers/AddAddressForm";
import ReOrdersAddAddressForm from "../../../../Drawers/ReOrder/ReOrdersAddAddressForm";
import BookingInfoDrawerNew from "../../../../Drawers/BookingInfoDrawerNew";
import profileNoBooking from "../../../../Images/no-booking.png";
import { MdOutlineMessage } from "react-icons/md";
import { getChatData } from "../../../../redux/chatData";

const SpecificService = () => {
  const theme = useTheme();
  const [bookingInfo, setBookingInfo] = useState([]);
  const { id } = useParams();
  const settings = useSelector((state) => state.Settings)?.settings;
  const otpSystem = settings?.general_settings?.otp_system;
  const currency_symbol = settings?.app_settings?.currency;
  const authentication = useSelector(
    (state) => state.authentication
  )?.isLoggedIn;
  const [service, setService] = useState(0);
  const [company, setCompany] = useState("");
  const [open, setOpen] = useState(false);

  const [checked, setchecked] = useState();
  const [openRescheduleDialog, setOpenRescheduleDialog] = useState(false);
  const [slot, setSlot] = useState("");
  const [timeSlot, setTimeSlot] = useState([]);
  const [noSlotAvailable, setNoSlotAvailable] = useState("");
  const [submission, setSubmission] = useState(false);
  const [cancellation, setCancellation] = useState(false);
  const [providerID, setProviderID] = useState(0);
  const [Downloading, setDownloading] = useState(false);
  const baseCart = useSelector((state) => state.cart)?.base_cart;
  const [providerData, setProviderData] = useState([]);
  const [selectedDate, setSelectedDate] = useState(
    dayjs().format("YYYY-MM-DD")
  );

  const locationData = useSelector((state) => state.Location);

  const orderDetails = useSelector(
    (state) => state.OrderCartDetails
  )?.orderDetails;
  const dispatch = useDispatch();
  const selectedCalendarDate = orderDetails && orderDetails.date;

  const handleService = (serviceData, company) => {
    setService(serviceData);
    setCompany(company);
    setOpen(!open);
  };

  const handleReschedule = async (e) => {
    setService(e);
    setOpenRescheduleDialog(!openRescheduleDialog);
  };

  const newHandleReschedule = async (id) => {
    const date = dayjs(selectedDate).format("YYYY-MM-DD");
    try {
      const providerResponse = await api.get_providers({
        latitude: locationData.lat,
        longitude: locationData.lng,
        id: id,
      });
      setProviderData(providerResponse.data);
      const response = await api.get_available_slot({
        partner_id: id,
        selectedDate: date,
      });
      setTimeSlot(response?.data?.all_slots);
      setNoSlotAvailable(response?.message);
      setProviderID(id);
      if (response.error) {
        // toast.error(response.message);
        setNoSlotAvailable(response?.message);
      }
    } catch (error) {
      setNoSlotAvailable("");
      console.log("error", error);
    }
  };

  useEffect(() => {
    newHandleReschedule(providerID);
  }, [selectedDate]);

  const TransferedData = useSelector((state) => state.Pages).bookings?.filter(
    (booking) => {
      return booking.id == id;
    }
  );

  useEffect(() => {
    const fetchBookingInfo = async () => {
      if (TransferedData?.length !== 0) {
        setBookingInfo(TransferedData);
      } else if (bookingInfo?.length === 0) {
        try {
          const result = await api.getOrders({ id: id });
          setBookingInfo(result.data);
        } catch (error) {
          console.log("error", error);
        }
      }
    };

    fetchBookingInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate, open]);

  useEffect(() => {
    const company_name = process.env.REACT_APP_NAME;
    document.title = `My Booking - Bookings | ${company_name}`;
  }, []);

  const handleChange = (event, slot) => {
    setchecked(slot);
    setSlot(event.time);
  };

  const handleScheduleChnage = async () => {
    if (slot === "") {
      return toast.error("Please select Time From available slots");
    }
    setSubmission(true);
    await api
      .change_order_status({
        order_id: id,
        status: "rescheduled",
        date: selectedDate,
        time: slot,
      })
      .then((result) => {
        setSubmission(false);
        if (result.error == true) {
          if (typeof result.message == "string") toast.error(result.message);
          else {
            Object.values(result.message).forEach((e) => {
              toast.error(e);
            });
          }
        } else {
          toast.success(result.message);
          setBookingInfo(result?.data?.data);
          setOpenRescheduleDialog(!openRescheduleDialog);
        }
        // window.location.reload();
      });
  };

  const handleOrderCancelattion = async () => {
    setCancellation(true);
    await api
      .change_order_status({ order_id: id, status: "cancelled" })
      .then((result) => {
        setCancellation(false);
        if (result.error == true) {
          if (typeof result.message == "string") toast.error(result.message);
          else {
            Object.values(result.message).forEach((e) => {
              toast.error(e);
            });
          }
        } else {
          setBookingInfo(result?.data?.data);
          toast.success(result.message);
        }
      });
  };

  const DownloadInvoice = async () => {
    setDownloading(true);

    await api.download_invoices({ order_id: id }).then(async (result) => {
      // Convert the API response to a Blob object
      const blob = new Blob([result], { type: "application/pdf" });
      // Create a new anchor element and set its href attribute to the Blob object
      const downloadLink = document.createElement("a");
      downloadLink.href = URL.createObjectURL(blob);
      downloadLink.download = `eDemand-invoice-${id}.pdf`;

      // Append the anchor element to the DOM and click it to initiate the download
      document.body.appendChild(downloadLink);
      downloadLink.click();

      // Remove the anchor element from the DOM
      document.body.removeChild(downloadLink);

      // Set your state, if needed (e.g., setDownloading(false))
      setDownloading(false);
    });
  };

  const advanceBookingDays =
    providerData && providerData[0]?.advance_booking_days;
  const disableDateAfter = dayjs().add(advanceBookingDays - 1, "day");

  const shouldDisableDate = (date) => {
    const today = dayjs().startOf("day"); // Get the start of today
    return date.isBefore(today) || date.isAfter(disableDateAfter);
  };

  const navigate = useNavigate();

  const removePromo = () => {
    dispatch(setPromoCode([]));
  };

  // Arrow function for when user click on add button request sent to api with 1 Qty
  const handleReorderOpen = async (response) => {
    if (!authentication) {
      toast.error("You need to login before adding Items to your account");
      return true;
    }
    try {
      removePromo();

      const cartResponse = await api.get_cart({ order_id: response[0].order_id });
      dispatch(setReorder(cartResponse?.reorder_data));
      dispatch(setFrom("reorder"));
      handleOpen(setForm);
    } catch (error) {
      console.log("error", error);
    }

  };

  const getTimeOfDay = (time) => {
    const hours = parseInt(time.split(":")[0]);

    if (hours >= 0 && hours < 6) {
      return "Night";
    } else if (hours < 12) {
      return "Morning";
    } else if (hours < 14) {
      return "Noon";
    } else if (hours < 18) {
      return "Afternoon";
    } else if (hours < 20) {
      return "Evening";
    } else if (hours < 24) {
      return "Night";
    } else {
      return "Midnight";
    }
  };

  const copyOtp = async (otp) => {
    try {
      await navigator.clipboard.writeText(otp);
      // Show toast message
      toast.success("OTP copied successfully!");
    } catch (err) {
      // Show error toast message
      toast.error("Failed to copy OTP");
    }
  };

  const [cart, setCart] = useState(false);
  const [form, setForm] = useState(false);
  const [addressFrom, setAddressForm] = useState(false);
  const [booking, setBooking] = useState(false);
  const [promo, setPromo] = useState(false);
  const [selectSlote, isSelectedSlote] = useState(false);
  const [addAddress, setAddAddress] = useState(false);

  function BookingDetails() {
    handleClose(setForm);
    handleOpen(setBooking);
  }

  function OpenMapDrawer() {
    handleOpen(setAddAddress);
    handleClose(setForm);
  }

  function CompleteAddress() {
    handleClose(setAddAddress);
    handleOpen(setAddressForm);
  }

  function BookingDrawer() {
    handleClose(isSelectedSlote);
    handleOpen(setBooking);
  }

  const handleChat = (e, data) => {
    e.preventDefault();
    if (!authentication) {
      toast.error("you need to login first!");
      return false;
    }
    try {
      getChatData({
        booking_id: data?.id,
        partner_id: data?.partner_id,
        partner_name: data?.company_name,
        image: data?.profile_image,
        order_status: data?.status,
      });
      navigate("/chat");
    } catch (error) {
      console.log(error);
    }
  };

  const calenderDateSelect = (value) => {
    setSelectedDate(dayjs(value).format("YYYY-MM-DD"));
  };
  return (
    <Layout>
      <Container className="mainContainer">
        <Grid spacing={3} container>
          <Grid item xs={12} md={4}>
            <Pnavigation />
          </Grid>
          <Grid item xs={12} md={8}>
            <Heading heading={t("booking_information")} />
            <Box
              padding={2}
              maxWidth={"100%"}
              borderColor={"#707070"}
              className="details_specific_service"
              borderRadius={"10px"}
              marginBottom={"20px"}
            >
              {bookingInfo ? (
                bookingInfo.map((bookData) => {
                  return (
                    <Box
                      key={bookData.id}
                      border={"1px solid"}
                      borderColor={"#707070"}
                      borderRadius={3}
                    >
                      <Box
                        display={"flex"}
                        justifyContent={"space-between"}
                        p={1}
                        maxWidth={"100%"}
                        sx={{ flexDirection: { xs: "column", md: "row" } }}
                        alignItems={"center"}
                        mb={1}
                      >
                        <Box
                          display={"flex"}
                          sx={{
                            flexDirection: { xs: "column", md: "row" },

                            textAlign: { xs: "center", md: "left" },
                          }}
                          alignItems={"center"}
                        >
                          <Box height={"100px"} width={"100px"}>
                            <img
                              src={bookData.profile_image}
                              height={"100%"}
                              width={"100%"}
                              alt="serviceimage"
                              className="border-radius-10"
                              onError={placeholderImage}
                            />
                          </Box>
                          <Box display={"block"}>
                            <Typography variant="h5" ml={2} fontWeight={"bold"}>
                              {bookData.company_name}
                            </Typography>
                            <Typography ml={2} display={"flex"} gap={1}>
                              <span>{t("invoice")}:</span>
                              <Box sx={{ color: "#0277FA" }}>
                                {bookData.invoice_no}
                              </Box>
                            </Typography>
                            <Typography ml={2} display={"flex"} gap={1}>
                              <span>{t("service_at")}:</span>
                              <Box sx={{ color: "#0277FA" }}>
                                {bookData.address_id == "0"
                                  ? "STORE"
                                  : "DOORSTEP"}
                              </Box>
                            </Typography>
                            <Typography
                              ml={2}
                              mt={0.2}
                              sx={{ color: "#0277FA" }}
                              fontWeight={"bolder"}
                            >
                              {currency_symbol} {bookData.final_total}
                            </Typography>
                          </Box>
                        </Box>
                        <Box p={1}>
                          <Button
                            variant="outlined"
                            size="small"
                            sx={{
                              width: "100%",
                            }}
                            className={`mt-1 mr-1 ${getStatusClassName(
                              bookData.status
                            )}`}
                          >
                            {bookData.status}
                          </Button>

                          {bookData.status !== "completed" ||
                          bookData.status !== "started" ||
                          bookData.status !== "awaiting" ||
                          bookData.status !== "confirmed" ? (
                            <Box>
                              {bookData.status !== "cancelled" ? (
                                <>
                                  <>
                                    {bookData.status == "awaiting" ||
                                    bookData.status == "confirmed" ? (
                                      <>
                                        <IconButton
                                          key={bookData.id}
                                          variant="contained"
                                          className="reschedule"
                                          size="small"
                                          sx={{
                                            fontSize: "small",
                                            border: " 1px solid",
                                            borderRadius: "5px",
                                            marginTop: "5px",
                                            fontWeight: "600",
                                            width: "100%",
                                          }}
                                          color="primary"
                                          onClick={(e) => {
                                            handleReschedule(1);
                                            newHandleReschedule(
                                              bookData.partner_id
                                            );
                                          }}
                                        >
                                          {/* <img
                                            src={reScheduleImage}
                                            alt="reschedule"
                                          /> */}
                                          {t("reschedule")}
                                        </IconButton>
                                      </>
                                    ) : (
                                      ""
                                    )}
                                  </>
                                  {bookData.is_cancelable == 1 ? (
                                    <IconButton
                                      key={bookData.id}
                                      variant="contained"
                                      className="button-background cancel-btn"
                                      size="small"
                                      color="error"
                                      onClick={(e) =>
                                        handleOrderCancelattion(bookData)
                                      }
                                      disabled={
                                        cancellation == true ? true : false
                                      }
                                    >
                                      {cancellation == false ? (
                                        <>
                                          {/* <CancelOutlined className="cancel-icon" /> */}
                                          {t("cancel_order")}
                                        </>
                                      ) : (
                                        <>
                                          {/* <FontAwesomeIcon
                                            icon={faSpinner}
                                            spin
                                          /> */}
                                          {t("cancel_order")}
                                        </>
                                      )}
                                    </IconButton>
                                  ) : (
                                    ""
                                  )}
                                </>
                              ) : null}
                            </Box>
                          ) : (
                            ""
                          )}

                          {/* otp button */}
                          {otpSystem === "1" && (
                            <Box
                              sx={{
                                marginTop: "5px",
                              }}
                            >
                              <Button
                                size="medium"
                                sx={{
                                  border: "1px solid #ffc200",
                                  color: "#bd8d00",
                                  backgroundColor: "#FFF3CD",
                                  textTransform: "none",
                                  width: "100%",
                                  height: "30.75px",
                                }}
                                onClick={() => copyOtp(bookData.otp)}
                              >
                                {t("otp")} {bookData.otp}
                              </Button>
                            </Box>
                          )}

                          {bookData.status == "completed" ? (
                            <>
                              <Button
                                sx={{
                                  marginTop: "5px",
                                }}
                                key={bookData.id}
                                variant="outlined"
                                className="button-background"
                                size="small"
                                // color="primary"
                                onClick={(e) => DownloadInvoice(bookData.id)}
                                disabled={Downloading === true}
                              >
                                {Downloading === false ? (
                                  <>
                                    {t("download")}
                                    {""}
                                    {t("invoice")}
                                  </>
                                ) : (
                                  <>
                                    {/* <FontAwesomeIcon icon={faDownload} bounce /> */}
                                    {t("download")}
                                    {t("invoice")}
                                  </>
                                )}
                              </Button>

                              {/* reorder Button */}

                              <Box mt={1}>
                                <Button
                                  variant="outlined"
                                  size="medium"
                                  sx={{
                                    textTransform: "none",
                                    width: "100%",
                                    height: "30.75px",
                                  }}
                                  onClick={() =>
                                    handleReorderOpen(bookData.services)
                                  }
                                >
                                  {t("reorder")}
                                </Button>
                              </Box>
                            </>
                          ) : null}

                          <div className="chat_button">
                            <button
                              className=""
                              type="button"
                              onClick={(e) => handleChat(e, bookData)}
                            >
                              <span>{t("chat")}</span>
                              <span>
                                <MdOutlineMessage size={18} />
                              </span>
                            </button>
                          </div>
                        </Box>
                      </Box>
                      <Divider />

                      <Box
                        mx={1}
                        my={2}
                        px={2}
                        maxWidth={"100%"}
                        display={"flex"}
                        flexDirection={"column"}
                        gap={2}
                      >
                        <Box display={"flex"} alignItems={"flex-start"} gap={3}>
                          <AccessTime />
                          <Box>
                            <Typography fontSize={"16px"} fontWeight={"bold"}>
                              {bookData.new_start_time_with_date}
                            </Typography>
                            <Typography variant="caption">
                              {t("schedule")}
                            </Typography>
                          </Box>
                        </Box>

                        <Box
                          display={"flex"}
                          width={"100%"}
                          alignItems={"flex-start"}
                          gap={3}
                          overflow={"auto"}
                        >
                          <LocationOnOutlined />
                          <Box>
                            {bookData.address_id != "0" ? (
                              <>
                                <Typography
                                  fontSize={"16px"}
                                  fontWeight={"bold"}
                                  sx={{ overflow: "hidden" }}
                                  className="booking-information"
                                >
                                  {bookData.address}
                                </Typography>
                                <Typography
                                  variant="caption"
                                  className="booking-information"
                                >
                                  {t("address")}
                                </Typography>
                              </>
                            ) : (
                              <>
                                <Typography
                                  fontSize={"16px"}
                                  fontWeight={"bold"}
                                  sx={{ overflow: "hidden" }}
                                  className="booking-information"
                                >
                                  {bookData.partner_address}
                                </Typography>
                                <Typography
                                  variant="caption"
                                  className="booking-information"
                                >
                                  {t("provider_address")}
                                </Typography>
                              </>
                            )}
                          </Box>
                        </Box>

                        {bookData?.remarks ? (
                          <Box
                            display={"flex"}
                            alignItems={"flex-start"}
                            gap={3}
                          >
                            <EventNoteOutlined />
                            <Box
                              sx={{
                                maxWidth: {
                                  xs: "80%",
                                  sm: "90%",
                                  md: "93%",
                                },
                              }}
                            >
                              {" "}
                              {/* Adjust max-width as needed */}
                              <>
                                <Typography
                                  fontSize={"16px"}
                                  fontWeight={"bold"}
                                  sx={{
                                    whiteSpace: "pre-line",
                                    wordWrap: "break-word",
                                  }}
                                >
                                  {bookData.remarks}
                                </Typography>
                                <Typography variant="caption">
                                  {t("notes")}
                                </Typography>
                              </>
                            </Box>
                          </Box>
                        ) : null}
                      </Box>

                      {/* work proof */}
                      <Box
                        mx={1}
                        my={2}
                        px={2}
                        maxWidth={"100%"}
                        display={"flex"}
                        flexDirection={"column"}
                        gap={2}
                      >
                        {bookData &&
                        bookData?.work_started_proof?.length > 0 ? (
                          <>
                            <Box className="started_proof">
                              <Typography fontSize={"16px"} fontWeight={"bold"}>
                                {t("work_start_proof")}
                              </Typography>
                              <UrlTypeComponent
                                urls={bookData.work_started_proof}
                              />
                            </Box>
                          </>
                        ) : null}

                        {bookData &&
                        bookData?.work_completed_proof?.length > 0 ? (
                          <>
                            <Box className="completed_proof">
                              <Typography fontSize={"16px"} fontWeight={"bold"}>
                                {t("work_complete_proof")}
                              </Typography>
                              <UrlTypeComponent
                                urls={bookData.work_completed_proof}
                              />
                            </Box>
                          </>
                        ) : null}
                      </Box>

                      <Divider />
                      <Box mt={1} ml={3} mr={3} pl={1}>
                        <Box mt={2} mb={2}>
                          {bookData &&
                            bookData.services.map((service) => {
                              return (
                                <Box
                                  key={service.id}
                                  display={"flex"}
                                  sx={{
                                    justifyContent: "space-between",
                                    flexDirection: { xs: "column", md: "row" },
                                  }}
                                  gap={2}
                                  mb={2}
                                >
                                  <Box>
                                    <Typography>
                                      {service.service_title}
                                    </Typography>
                                    <Typography>
                                      {service.quantity} * {currency_symbol}
                                      {service.price_with_tax}
                                    </Typography>
                                  </Box>

                                  <Box>
                                    <Typography
                                      color={"var(--global-theme)"}
                                      fontWeight={"bold"}
                                    >
                                      {currency_symbol} {service.price_with_tax}
                                    </Typography>
                                    {service.status == "completed" ? (
                                      <Button
                                        key={service.id}
                                        variant="contained"
                                        className="button-background"
                                        size="small"
                                        sx={{
                                          backgroundColor:
                                            theme.palette.background
                                              .buttonColor,
                                          "&:hover": {
                                            backgroundColor:
                                              theme.palette.background
                                                .buttonColor,
                                          },
                                        }}
                                        onClick={(e) =>
                                          handleService(
                                            service,
                                            bookData.company_name
                                          )
                                        }
                                      >
                                        {t("rate")}
                                      </Button>
                                    ) : (
                                      ""
                                    )}
                                  </Box>
                                </Box>
                              );
                            })}
                        </Box>
                      </Box>

                      <Divider />
                      <Box bgcolor={"#2560FC1A"}>
                        <Box ml={3} mr={3} pl={1}>
                          <Box py={2}>
                            <Box
                              sx={{
                                display: "flex",
                                justifyContent: "space-between",
                              }}
                            >
                              <Box
                                sx={{
                                  display: "flex",
                                  justifyContent: "space-between",
                                  flexDirection: "column",
                                  gap: 1,
                                }}
                              >
                                <Typography className="booking-information">
                                  {t("sub_total")}
                                </Typography>
                                {bookData?.tax_amount != 0 ? (
                                  <Typography className="booking-information">
                                    {t("Tax")}
                                  </Typography>
                                ) : null}
                                {bookData?.visiting_charges != 0 ? (
                                  <Typography className="booking-information">
                                    {t("visiting_charge")}
                                  </Typography>
                                ) : null}
                                {bookData?.promo_code !== "" ? (
                                  <Typography className="booking-information">
                                    {t("promo_code_discount")}
                                  </Typography>
                                ) : (
                                  ""
                                )}
                                <Typography
                                  className="booking-information"
                                  fontWeight={"bold"}
                                >
                                  {t("total")}
                                </Typography>
                              </Box>
                              <Box
                                sx={{
                                  display: "flex",
                                  justifyContent: "space-between",
                                  flexDirection: "column",
                                  gap: 1,
                                }}
                              >
                                <Typography className="booking-information">
                                  {currency_symbol}
                                  {bookData.total}
                                </Typography>
                                {bookData?.tax_amount != 0 ? (
                                  <Typography className="booking-information">
                                    + {currency_symbol}
                                    {bookData.tax_amount}
                                  </Typography>
                                ) : null}
                                {bookData?.visiting_charges != 0 ? (
                                  <Typography className="booking-information">
                                    + {currency_symbol}
                                    {bookData.visiting_charges}
                                  </Typography>
                                ) : null}
                                {bookData.promo_code !== "" ? (
                                  <Typography className="booking-information">
                                    - {currency_symbol}
                                    {bookData.promo_discount}
                                  </Typography>
                                ) : (
                                  ""
                                )}
                                <Typography
                                  className="booking-information"
                                  fontWeight={"bold"}
                                >
                                  {currency_symbol}
                                  {bookData.final_total}
                                </Typography>
                              </Box>
                            </Box>
                          </Box>
                        </Box>
                      </Box>
                    </Box>
                  );
                })
              ) : (
                <Box
                  className="textaling-center minHeight-550"
                  display={"flex"}
                  flexDirection={"column"}
                  gap={3}
                >
                  <h2>{t("no_bookings_yet")}</h2>
                  <Box
                    display={"flex"}
                    justifyContent={"center"}
                    textAlign={"center"}
                  >
                    <img
                      src={profileNoBooking}
                      height={"300px"}
                      width={"300px"}
                      alt="no bookings"
                      onError={placeholderImage}
                    />
                  </Box>
                  <p>{t("book_first_service")}</p>
                  <Button
                    variant="outlined"
                    onClick={() => navigate("/providers")}
                  >
                    {t("explore")}
                  </Button>
                </Box>
              )}
            </Box>
          </Grid>
        </Grid>

        {open === true ? (
          <RatingModal
            open={open}
            setOpen={setOpen}
            service={service}
            company={company}
          />
        ) : (
          ""
        )}

        {/* Reshdule Order */}
        <Dialog
          maxWidth="lg"
          sx={{
            "& .MuiDialog-container": {
              "& .MuiPaper-root": {
                margin: {
                  xs: 1,
                },
              },
            },
            maxWidth: { xs: "100%", md: "100%" },
          }}
          open={openRescheduleDialog}
        >
          <DialogTitle>
            <Box display={"flex"} justifyContent={"space-between"}>
              <Typography variant="h6">{t("order_reschedule")}</Typography>

              <IconButton
                aria-label="Close Button"
                onClick={(e) => setOpenRescheduleDialog(!openRescheduleDialog)}
              >
                <CloseOutlined />
              </IconButton>
            </Box>
          </DialogTitle>
          <Divider />
          <Box
            sx={{ width: { xs: "100%", md: 700 } }}
            display={"flex"}
            flexDirection={"column"}
            gap={3}
            m={1}
          >
            <Box>
              <FormLabel htmlFor="select_date"> {t("select_date")}</FormLabel>

              <Box sx={{ mt: 1 }}>
                <Calendar
                  value={
                    selectedCalendarDate
                      ? selectedCalendarDate
                      : dayjs(selectedDate)
                  }
                  onChange={(newValue) => {
                    calenderDateSelect(newValue);
                  }}
                  tileDisabled={({ date, view }) =>
                    shouldDisableDate(dayjs(date))
                  }
                  prev2Label={null} // Hide the "previous year" navigation label
                  next2Label={null} // Hide the "next year" navigation label
                />
              </Box>

              <FormLabel
                htmlFor="time"
                sx={{
                  py: "15px",
                }}
              >
                {" "}
                {t("select_time")}
              </FormLabel>
              <Box className="slot_data">
                {timeSlot && timeSlot?.length !== 0 ? (
                  timeSlot.map((slot, index) => (
                    <Box
                      key={slot.time}
                      sx={{
                        width: { xs: "46%", md: "15%" },
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        border: "1px solid",
                        borderRadius: "15px",
                        p: 1,
                        backgroundColor: slot.is_available === 0 ? "gray" : "",
                      }}
                    >
                      <Radio
                        checked={index === checked}
                        onChange={() => handleChange(slot, index)}
                        value={index}
                        name="radio-buttons"
                        inputProps={{ "aria-label": slot.time }}
                        disabled={slot.is_available === 0}
                        sx={{ p: "2px" }}
                      />
                      <Divider sx={{ width: "100%" }} />
                      <Box pt={"5px"} textAlign={"center"}>
                        <Typography variant="subtitle2">
                          {getTimeOfDay(slot.time)}
                        </Typography>
                        <Typography variant="body2">{slot.time}</Typography>
                      </Box>
                    </Box>
                  ))
                ) : (
                  <Box
                    display={"flex"}
                    justifyContent={"center"}
                    alignItems={"center"}
                    textAlign={"center"}
                  >
                    <Box>
                      <Card sx={{ boxShadow: "none" }}>
                        <CardMedia
                          component="img"
                          src={profileNoBooking}
                          alt="no time slot"
                          sx={{ width: 260, height: 260 }}
                        />
                      </Card>
                      <Typography variant="h6" sx={{ width: 260 }}>
                        {noSlotAvailable}
                      </Typography>
                    </Box>
                  </Box>
                )}
              </Box>

              <Box mt={2}>
                <Button
                  variant="contained"
                  onClick={(e) => handleScheduleChnage()}
                  disabled={submission == true ? true : false}
                  startIcon={
                    submission == true ? (
                      <FontAwesomeIcon icon={faSpinner} spin />
                    ) : (
                      ""
                    )
                  }
                >
                  {t("change_schedule")}{" "}
                </Button>
              </Box>
            </Box>
          </Box>
        </Dialog>

        {/* Select Date and time and based on that We send request to check available slot */}
        <Drawer
          open={form}
          anchor="right"
          sx={{
            display: { xs: "block", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: { md: 580, xs: "100%" },
            },
          }}
        >
          <Box>
            <ReOrdersAddAddressForm
              setCart={setCart}
              setForm={setForm}
              isSelectedSlote={isSelectedSlote}
              continueFun={BookingDetails}
              MyFun={OpenMapDrawer}
              setBooking={setBooking}
            />
          </Box>
        </Drawer>

        {/* In this drawer we provide them clanader and list all available time slotes and on select another request send to same api */}
        <Drawer
          open={selectSlote}
          anchor="right"
          sx={{
            display: { xs: "block", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: { md: 580, xs: "100%" },
            },
          }}
        >
          <Box>
            <ConfirmDateTime
              setForm={setForm}
              isSelectSlote={isSelectedSlote}
              booking={BookingDrawer}
            />
          </Box>
        </Drawer>

        {/* if user want to address than add address drawer  */}
        <Drawer
          open={addAddress}
          anchor="right"
          sx={{
            display: { xs: "block", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: { md: 580, xs: "100%" },
            },
          }}
        >
          <Box>
            <AddAddressForm
              CompleteAddress={CompleteAddress}
              setForm={setForm}
              addAddress={setAddAddress}
            />
          </Box>
        </Drawer>

        {/* booking information drawer  */}
        <Drawer
          open={booking}
          anchor="right"
          sx={{
            display: { xs: "block", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: { md: 580, xs: "100%" },
            },
          }}
        >
          <Box>
            <BookingInfoDrawerNew
              setForm={setForm}
              setBooking={setBooking}
              setPromo={setPromo}
            />
          </Box>
        </Drawer>

        {/* promocode drawer  */}
        <Drawer
          open={promo}
          anchor="right"
          sx={{
            display: { xs: "block", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: { md: 580, xs: "100%" },
            },
          }}
        >
          <Box>
            <Promocode setBooking={setBooking} setPromo={setPromo} />
          </Box>
        </Drawer>
      </Container>
    </Layout>
  );
};

export default SpecificService;
