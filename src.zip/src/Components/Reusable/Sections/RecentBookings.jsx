import {
  Box,
  Container,
  Divider,
  Skeleton,
  Typography,
  useTheme,
  LinearProgress,
  useMediaQuery,
  Button,
  Card,
  CardContent,
} from "@mui/material";
import { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import "swiper/css";
import { Grid, Avatar } from "@mui/material";
import { useNavigate } from "react-router";
import api from "../../../API/apiCollection";
import { t } from "i18next";
import { useSelector } from "react-redux";

const RecentBookings = ({ data, loading }) => {
  // eslint-disable-next-line no-unused-vars
  const [swiper, setSwiper] = useState(null);
  const theme = useTheme();
  const navigate = useNavigate();

  const [progress, setProgress] = useState(0.05); // Initially filled 5%
  const isMdScreen = useMediaQuery("(min-width:1025px)"); // Check if screen size is medium (md) or larger
  const [Downloading, setDownloading] = useState(false);


  const authentication = useSelector(
    (state) => state.authentication
  )?.isLoggedIn;

  useEffect(() => {
    const updateProgress = () => {
      if (swiper) {
        const { progress } = swiper;
        setProgress(progress);
      }
    };

    if (swiper) {
      swiper.on("progress", updateProgress);
    }

    return () => {
      if (swiper) {
        swiper.off("progress", updateProgress);
      }
    };
  }, [swiper]);

  const handleViewServices = (e, id) => {
    e.preventDefault();
    navigate("/profile/booking/services/" + id);
  };

  const DownloadInvoice = async (id) => {
    setDownloading(true);

    await api.download_invoices({ order_id: id }).then(async (result) => {
      // Convert the API response to a Blob object
      const blob = new Blob([result], { type: "application/pdf" });
      // Create a new anchor element and set its href attribute to the Blob object
      const downloadLink = document.createElement("a");
      downloadLink.href = URL.createObjectURL(blob);
      downloadLink.download = `eDemand-invoice-${id}.pdf`;

      // Append the anchor element to the DOM and click it to initiate the download
      document.body.appendChild(downloadLink);
      downloadLink.click();

      // Remove the anchor element from the DOM
      document.body.removeChild(downloadLink);

      // Set your state, if needed (e.g., setDownloading(false))
      setDownloading(false);
    });
  };
  return (
    <>
      {data && authentication && data?.previous_order?.length > 0 ? (
        <Box sx={{ background: theme.palette.background.box }}>
          <Container
            sx={{ paddingBottom: "8px", marginBottom: "16px" }}
            className="mainContainer subCategoriesSection"
          >
            <Box
              key={data.id}
              sx={{
                padding: "30px 0px",
                paddingBottom: "0px",
                margin: "30px 0px",
              }}
            >
              <Box
                display={"flex"}
                justifyContent={"space-between"}
                alignItems={"end"}
              >
                {loading ? (
                  <Skeleton height={50} width={200} />
                ) : (
                  <Box>
                    <Typography
                      sx={{
                        textTransform: "capitalize",
                        marginBottom: "10px",
                        typography: { md: "h5", xs: "body1" },
                        fontWeight: "600 !important", // Set font weight to 400
                      }}
                      fontWeight={"bold"} // This line is redundant, you can remove it
                      marginTop={1}
                    >
                      {data.title}
                    </Typography>
                  </Box>
                )}

                {loading ? "" : null}
              </Box>
              {isMdScreen ? (
                <Divider sx={{ my: 1 }} />
              ) : (
                <LinearProgress variant="determinate" value={progress * 100} />
              )}
              <Box mb={2}>
                <Swiper
                  className="swiper-wrapper-padding h-auto"
                  slidesPerView={5}
                  onSwiper={(s) => {
                    setSwiper(s);
                  }}
                  modules={[Navigation]}
                  navigation
                  breakpoints={{
                    0: {
                      slidesPerView: 1,
                      spaceBetween: 10,
                    },
                    640: {
                      slidesPerView: 2,
                      spaceBetween: 20,
                    },
                    898: {
                      slidesPerView: 3,
                      spaceBetween: 30,
                    },
                    1200: {
                      slidesPerView: 3,
                      spaceBetween: 15,
                    },
                    1400: {
                      slidesPerView: 3.5,
                      spaceBetween: 15,
                    },
                  }}
                >
                  <Box>
                    <Swiper
                      navigation={true}
                      modules={[Navigation]}
                      className="mySwiper max-h-500"
                    >
                      {data &&
                        data?.previous_order.map((booking) => (
                          <SwiperSlide key={booking.id}>
                            <Card
                              sx={{
                                backgroundColor: theme.palette.background.card,
                                border: "1px solid #00000017",
                                color: theme.palette.color.categories,
                                maxWidth: 350,
                                margin: "10px 0",
                              }}
                            >
                              <CardContent
                                sx={{
                                  padding: "16px !important",
                                }}
                              >
                                <Grid
                                  container
                                  justifyContent="space-between"
                                  alignItems="center"
                                >
                                  <Typography
                                    variant="body2"
                                    color={theme.palette.primary.main}
                                  >
                                    {t("invoice")}: {booking.invoice_no}
                                  </Typography>
                                  <Typography
                                    variant="body2"
                                    sx={{
                                      color: "green",
                                      fontWeight: "bold",
                                    }}
                                  >
                                    {booking.status === "completed"
                                      ? "Completed"
                                      : ""}
                                  </Typography>
                                </Grid>

                                <Box sx={{ mt: 1 }}>
                                  {booking?.services
                                    .slice(0, 2)
                                    .map((service, index) => (
                                      <Typography
                                        key={index}
                                        variant="body1"
                                        sx={{
                                          color: theme.palette.color.textColor,
                                        }}
                                      >
                                        {service.service_title}
                                      </Typography>
                                    ))}
                                  {booking?.services.length > 2 && (
                                    <Typography
                                      variant="body1"
                                      sx={{
                                        color: theme.palette.color.textColor,
                                      }}
                                    >
                                      +{booking?.services.length - 2}{" "}
                                      {t("more")}
                                    </Typography>
                                  )}
                                </Box>

                                <Grid
                                  container
                                  justifyContent="space-between"
                                  alignItems="center"
                                  sx={{ mt: 2 }}
                                >
                                  <Grid
                                    item
                                    sx={{
                                      display: "flex",
                                      alignItems: "center",
                                      gap: "10px",
                                    }}
                                  >
                                    <Avatar
                                      alt={booking.company_name}
                                      src={booking.profile_image}
                                      sx={{ width: 40, height: 40 }}
                                    />
                                    <Typography
                                      variant="body2"
                                      sx={{
                                        color: theme.palette.color.textColor,
                                      }}
                                    >
                                      {booking.company_name}
                                    </Typography>
                                  </Grid>
                                </Grid>
                                <Grid
                                  container
                                  spacing={1}
                                  sx={{
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    marginTop: 2,
                                  }}
                                >
                                  <Grid item xs={12} md={6}>
                                    <Button
                                      key={booking.id}
                                      variant="outlined"
                                      className="button-background"
                                      sx={{
                                        textTransform: "capitalize",
                                        color: theme.palette.primary.main,
                                        width: "100%",
                                      }}
                                      // color="primary"
                                      onClick={(e) =>
                                        DownloadInvoice(booking.id)
                                      }
                                      disabled={Downloading === true}
                                    >
                                      {Downloading === false ? (
                                        <>
                                          {t("download")}
                                          {""}
                                          {t("invoice")}
                                        </>
                                      ) : (
                                        <>
                                          {/* <FontAwesomeIcon icon={faDownload} bounce /> */}
                                          {t("download")}
                                          {t("invoice")}
                                        </>
                                      )}
                                    </Button>
                                  </Grid>
                                  <Grid item xs={12} md={6}>
                                    <Button
                                      variant="contained"
                                      onClick={(e) =>
                                        handleViewServices(e, booking.id)
                                      }
                                      sx={{
                                        backgroundColor: "#1976d2",
                                        color: "#fff",
                                        width: "100%",
                                        textTransform: "none",
                                      }}
                                    >
                                      {t("view-services")}
                                    </Button>
                                  </Grid>
                                </Grid>
                              </CardContent>
                            </Card>
                          </SwiperSlide>
                        ))}
                    </Swiper>
                  </Box>
                </Swiper>
              </Box>
            </Box>
          </Container>
        </Box>
      ) : null}
    </>
  );
};

export default RecentBookings;
