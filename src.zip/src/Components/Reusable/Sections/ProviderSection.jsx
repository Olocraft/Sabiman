import {
  Box,
  Button,
  Container,
  Divider,
  Skeleton,
  Typography,
} from "@mui/material";
import "swiper/css";
import { useTheme } from "@emotion/react";
import Partner from "./Partner";
import { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";

const ProviderSection = ({ Provider, loading, isHome = false }) => {
  const [swiper, setSwiper] = useState(null);
  const theme = useTheme();
  // Function to handle sliding to the next slide
  const handleNextSlide = () => {
    if (swiper) {
      swiper.slideNext();
    }
  };

  // Function to handle sliding to the previous slide
  const handlePrevSlide = () => {
    if (swiper) {
      swiper.slidePrev();
    }
  };

  return (
    <div>
      <>
        <Box sx={{ background: theme.palette.background.box }}>
          <Container className="mainContainer servicesSections">
            <Box
              key={Provider.key}
              sx={{ padding: "30px 0px", margin: "30px 0px" }}
            >
              {loading ? (
                <Skeleton variant="rectangular" width={200} height={50} />
              ) : (
                <Box
                  display={"flex"}
                  justifyContent={"space-between"}
                  alignItems={"center"}
                >
                  <Box>
                    <Typography
                      sx={{
                        typography: { md: "h5", xs: "body1" },
                        fontWeight: "600 !important",
                      }}
                      mt={1}
                    >
                      {Provider.title}
                    </Typography>
                  </Box>
                </Box>
              )}

              <Divider sx={{ my: 1 }} />
              <Box
                pb={"12px"}
                mt={2}
                mb={2}
                sx={{
                  mr: { xs: 0 }, // Set mr to -2.1 for md screen size only
                }}
              >
                <Swiper
                  className="myslider h-auto"
                  pagination={{
                    type: "progressbar",
                  }}
                  slidesPerView={4}
                  freeMode={true}
                  modules={[Pagination, Navigation]}
                  onSwiper={(s) => {
                    setSwiper(s);
                  }}
                  breakpoints={{
                    0: {
                      slidesPerView: 1,
                      spaceBetween: 10,
                    },
                    575: {
                      slidesPerView: 1.5,
                      spaceBetween: 20,
                    },
                    768: {
                      slidesPerView: 2.5,
                      spaceBetween: 30,
                    },
                    1024: {
                      slidesPerView: 3,
                      spaceBetween: 10,
                    },
                    1200: {
                      slidesPerView: 4,
                      spaceBetween: 20,
                    },
                  }}
                >
                  {Provider.partners.map((partner) => {
                    return (
                      <SwiperSlide key={partner.id}>
                        <Box mt={4}>
                          <Partner
                            key={partner.id}
                            partner={partner}
                            isHome={isHome}
                          />
                        </Box>
                      </SwiperSlide>
                    );
                  })}
                </Swiper>
                {Provider?.partners?.length > 4 ?
                <Box
                  display={"flex"}
                  sx={{ my: 3 }}
                  gap={2}
                  width={"100%"}
                  justifyContent={"center"}
                  alignContent={"center"}
                  className="categoryNavigationBtns"
                >
                  <Button
                    aria-label="Previous"
                    variant="contained"
                    size="small"
                    color="inherit"
                    className="categorySwiperBtn"
                    sx={{
                      borderRadius: "10px",
                      minWidth: "40px",
                      backgroundColor: "#F2F1F6",
                      "&:hover": {
                        backgroundColor: "#F2F1F6",
                        textDecoration: "none",
                      },
                    }}
                    onClick={() => handlePrevSlide()}
                  >
                    <ArrowBackIosIcon sx={{ color: "black" }} size="small" />
                  </Button>
                  <Button
                    aria-label="Next"
                    variant="contained"
                    size="small"
                    color="inherit"
                    className="categorySwiperBtn"
                    sx={{
                      borderRadius: "10px",
                      minWidth: "40px",
                      py: 1,
                      backgroundColor: "#F2F1F6",
                      "&:hover": {
                        backgroundColor: "#F2F1F6",
                        textDecoration: "none",
                      },
                    }}
                    onClick={() => handleNextSlide()}
                  >
                    <ArrowForwardIosIcon sx={{ color: "black" }} size="small" />
                  </Button>
                  {/* <span className="previous-next-btn">
                        </span> */}
                </Box>
                : null}
              </Box>
            </Box>
          </Container>
        </Box>
      </>
    </div>
  );
};

export default ProviderSection;
