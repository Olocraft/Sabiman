/* eslint eqeqeq: 0 */
import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  IconButton,
  Typography,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { t } from "i18next";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import toast from "react-hot-toast";
import { useSelector, useDispatch } from "react-redux";
import {
  updateBaseCart,
  updateSelectedView,
} from "../../../redux/cart";
import StarIcon from "@mui/icons-material/Star";
import { setPromoCode } from "../../../redux/Promocode";
import { DECIMAL_POINT } from "../../../config/config";
import api from "../../../API/apiCollection";
import { useTheme } from "@emotion/react";
import { cartDetails } from "../../../redux/orderCartDetails";
import { setDeliveryAddress } from "../../../redux/DeliveryAddress";
import noProviderImage from "../../../Images/no-provider.png"
import { placeholderImage } from "../../../util/Helper";

const CartItem = ({ item, onDelete }) => {
  const cart = useSelector((state) => state.cart);

  const dispatch = useDispatch();

  function capitalizeFirstLetter(inputString) {
    if (typeof inputString !== "string" || inputString?.length === 0) {
      return inputString;
    }
    return inputString.charAt(0).toUpperCase() + inputString.slice(1);
  }

  const removePromo = () => {
    dispatch(setPromoCode([]));
  };

  // general function that we reuse to increment and decrement of items
  const handleAddCart = async (id, qty) => {
    try {
      removePromo();

      const result = await api.ManageCart({ id: id, qty: qty.toString() });
      const response = await api.get_cart();

      if (response.cart_data) dispatch(updateBaseCart(response.cart_data));

      if (response && response.data) {
        let message = capitalizeFirstLetter(result.message);
        toast.success(message);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const handleIncrement = (response) => {
    removePromo();
    cart?.base_cart?.data?.forEach((obj) => {
      if (obj.service_id === response.service_id && obj.qty > 0) {
        const quantity = parseInt(obj.qty);

        const allowed = parseInt(item.servic_details.max_quantity_allowed);

        if (allowed > quantity) {
          handleAddCart(response.service_id, quantity + 1);
        } else {
          toast.error(
            `Maximum Quantity is ${item.servic_details.max_quantity_allowed}`
          );
        }
      }
    });
  };

  // Arrow function forr when user decrement items it update Qty and send api request
  const handleDecrement = (response) => {
    removePromo();
    cart?.base_cart?.data?.forEach((obj) => {
      if (obj.service_id == response.service_id && parseInt(obj.qty) === 1) {
        return toast.error("Already at minimum quantity");
      }
      if (obj.service_id == response.service_id) {
        handleAddCart(response.service_id, parseInt(obj.qty) - 1);
      }
    });
  };

  const theme = useTheme();

  return (
    <Card
      sx={{
        display: "flex",
        gap: 2,
        padding: "10px",
        bgcolor: "transparent",
        boxShadow: "none",
        flexWrap:{xs:"wrap",md:"inherit"}
      }}
    >
      <img
        src={item.servic_details.image_of_the_service}
        alt={item.servic_details.title}
        onError={placeholderImage}
        className="cartItems_no_image"
      />
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          borderRadius: "8px",
        }}
      >
        <CardContent sx={{ flex: "1 0 auto", pt: 0 }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              justifyContent: "space-between",
            }}
          >
            <Typography
              component="div"
              color={theme?.palette?.primary?.main}
              fontWeight={"bold"}
              variant="subtitle1"
            >
              {item.servic_details.title}
            </Typography>
            <Box display={"flex"} alignItems={"self-start"}>
              <Typography component="div" variant="caption">
                <StarIcon sx={{ color: "gold" }} />
              </Typography>
              <Typography component="div" variant="subtitle1">
                {parseFloat(item.servic_details.rating).toFixed(1)}
              </Typography>
            </Box>
          </Box>
          <Typography
            variant="subtitle1"
            color="text.secondary"
            component="div"
          >
            {item.servic_details.number_of_members_required} Person |{" "}
            {item.servic_details.duration} Min
          </Typography>
        </CardContent>
        <Box
          sx={{ display: "flex", alignItems: "center", gap: 2, pl: 1, pb: 2 }}
        >
          <Box
            display="flex"
            alignItems="center"
            sx={{
              background: "#0277FA",
              width: "max-content",
              borderRadius: 2,
            }}
          >
            <IconButton
              onClick={() => {
                handleDecrement(item);
              }}
              disabled={cart?.base_cart?.data?.some((obj) => {
                if (obj.service_id == item.service_id && obj.qty === 1) {
                  return true;
                }
                return false;
              })}
            >
              <RemoveIcon className="color-white" />
            </IconButton>
            <Typography variant="body2" color={"white"}>
              {cart?.base_cart?.data?.map((obj) => {
                if (obj.service_id === item.service_id && obj.qty > 0) {
                  return <span key={obj.service_id}>{obj.qty}</span>;
                }
                return <></>;
              })}
            </Typography>
            <IconButton
              onClick={() => {
                handleIncrement(item);
              }}
            >
              <AddIcon className="color-white" />
            </IconButton>
          </Box>
          <Box
            display="flex"
            alignItems="center"
            sx={{
              backgroundColor: "#F44336",
              width: "max-content",
              borderRadius: 2,
            }}
          >
            <IconButton
              color="white"
              aria-label="Delete"
              onClick={() => {
                removePromo();
                onDelete(item);
              }}
            >
              <DeleteIcon sx={{ color: "white" }} />
            </IconButton>
          </Box>
        </Box>
      </Box>
    </Card>
  );
};

export const Cart = ({ continueClicked }) => {
  const decimal_point = DECIMAL_POINT();
  const dispatch = useDispatch();
  const cart = useSelector((state) => state.cart);
  dispatch(updateSelectedView(""));
  dispatch(setDeliveryAddress(""));
  dispatch(cartDetails({ orderNote: "" }));

  const theme = useTheme();

  const handleQuantityChange = (itemId, quantity) => {};

  const handleDelete = async (itemId) => {
    await api
      .removeCart({ itemId: itemId.service_id })
      .then(async (result) => {
        if(result) dispatch(updateBaseCart(result));
        toast.success(result.message);
      })
      .catch((error) => console.log("error", error));
  };

  const settings = useSelector((state) => state.Settings)?.settings;
  const currency_symbol = settings?.app_settings?.currency;

  return (
    <div>
      <Box padding={1}>
        <Divider />
        {cart?.base_cart?.length === 0 || cart?.base_cart?.data?.length === 0 ? (
          <Box textAlign={"center"} maxWidth={"100%"}>
            <Box
              component={"img"}
              src={noProviderImage}
              alt="Nothing in cart"
              sx={{ width: "100%", borderRadius: "500px" }}
            />
            <h3>{t("no_products")}</h3>
          </Box>
        ) : (
          <>
              {cart?.base_cart?.data?.map((item) => (
              <Box key={item.id}>
                <Box my={2} key={item.id}>
                  <CartItem
                    item={item}
                    key={item.id}
                    onDelete={handleDelete}
                    onQuantityChange={handleQuantityChange}
                  />
                </Box>
                <Divider sx={{ marginTop: 2 }} />
              </Box>
            ))}
          </>
        )}

        {cart?.base_cart == null || cart?.base_cart?.length === 0 || cart.base_cart?.data?.length === 0 ? (
          ""
        ) : (
          <Box
            mt={2}
            mb={2}
            borderRadius={"var( --global-border-radius)"}
            sx={{ backgroundColor: theme.palette.background.buttonColor }}
          >
            <Button
              variant="contained"
              fullWidth
              sx={{
                backgroundColor: "transparent",
                textAlign: "start",
                borderRadius: "var( --global-border-radius)",
                textTransform: "none",
                "&:hover": {
                  // Remove the hover effect styles here
                  backgroundColor: theme.palette.background.buttonColor,
                  // For example, make the background transparent on hover
                },
              }}
              onClick={() => continueClicked()}
            >
              <Box
                display={"flex"}
                width={"100%"}
                alignItems={"center"}
                justifyContent={"space-between"}
              >
                <Box display={"flex"} flexDirection={"column"}>
                  <Typography
                    variant="caption"
                    display={"flex"}
                    gap={0.5}
                    color={"white"}
                  >
                    {cart?.base_cart?.data?.length}
                    <Box>{t("items")}</Box>
                  </Typography>
                  <Typography variant="body2" color={"white"}>
                    {currency_symbol}{" "}
                    {parseFloat(cart?.base_cart?.sub_total).toFixed(
                      decimal_point
                    )}
                  </Typography>
                </Box>
                <Typography variant="body2" color={"white"}>
                  {t("continue")}
                </Typography>
              </Box>
            </Button>
          </Box>
        )}
      </Box>
    </div>
  );
};

export default Cart;
