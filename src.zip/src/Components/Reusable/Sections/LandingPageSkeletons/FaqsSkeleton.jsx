import { Skeleton } from '@mui/material'

const FaqsSkeleton = () => {
    return (
        Array.from({ length: 6 }).map((_, index) => (
            <div key={index}>
                <Skeleton width={'100%'} height={80} />
            </div>
        ))
    )
}

export default FaqsSkeleton
