import { Skeleton } from '@mui/material'
import React from 'react'
import CommonTextSkeleton from './CommonTextSkeleton'

const OurServicesSkeleton = () => {
    return (
        <section className='ourServices'>
            <div className='container custom-Container'>
                <CommonTextSkeleton />

                <div className="ourSericeSkeletonWrapper">
                    {
                        Array.from({ length: 6 }).map((_, index) => (
                            <div className="ourSericeSkeleton" key={index}>
                                <Skeleton className='cardSkeleton' />
                                <Skeleton className='imgSkeleton' />
                                <Skeleton className='textSkeleton' />
                            </div>))
                    }
                </div>
            </div>
        </section>
    )
}

export default OurServicesSkeleton
