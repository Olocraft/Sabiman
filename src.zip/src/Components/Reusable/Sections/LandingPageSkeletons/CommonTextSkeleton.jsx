import { Skeleton } from '@mui/material'
import React from 'react'

const CommonTextSkeleton = ({testimonialSect}) => {
    return (
        <div className="textWrapper">
            <span className='heading'>
                <Skeleton width={200} height={30} />
            </span>
            <span className='para'>
                <Skeleton width={250} height={20} />
                <Skeleton width={250} height={20} />
                <Skeleton width={250} height={20} />
            </span>
            {
                testimonialSect &&
                <div className="navigationBtns">

                    <Skeleton width={40} height={40} />
                    <Skeleton width={40} height={40} />

                </div>
            }
        </div>
    )
}

export default CommonTextSkeleton
