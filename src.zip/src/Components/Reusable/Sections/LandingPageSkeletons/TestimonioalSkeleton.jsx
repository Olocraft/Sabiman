import { Skeleton } from '@mui/material'
import React from 'react'
import CommonTextSkeleton from './CommonTextSkeleton'

const TestimonioalSkeleton = () => {
    return (
        <div className='row'>
            <div className="col-lg-3 textDiv">
                <CommonTextSkeleton testimonialSect={true}/>
            </div>
            <div className="col-lg-9 testimonialsCardSkeltonWrapper">
                <div className="row">
                    {Array.from({ length: 3 }).map((_, index) => (
                        <div className="col-lg-4" key={index}>
                            <div className="testimonialsCardSkeleton testimonialsCard">
                                <div className="quotesImg">
                                    <Skeleton width={40} height={50} />
                                </div>
                                <div>
                                    <Skeleton width={'100%'} height={20} />
                                    <Skeleton width={'100%'} height={20} />
                                    <Skeleton width={'100%'} height={20} />
                                    <Skeleton width={'100%'} height={20} />
                                </div>

                                <div className='profileWrapper'>

                                    <div className='profile'>
                                        <div>
                                            <Skeleton width={70} height={80} />
                                        </div>
                                        <div className='text'>
                                            <Skeleton width={80} height={20} />
                                            <Skeleton width={70} height={20} />
                                        </div>
                                    </div>

                                    <div className='ratingDiv'>
                                        <Skeleton width={40} height={40} />
                                        <Skeleton width={40} height={40} />
                                    </div>

                                </div>

                            </div>
                        </div>
                    ))}
                </div>

            </div>
        </div>
    )
}

export default TestimonioalSkeleton
